//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GENERIC.RC
// $Id$
#define IDC_USERID                      1051
#define IDC_REALNAME                    1052
#define IDC_PNICK                       1053
#define IDC_ANICK                       1054
#define IDC_SERVERLIST                  1057
#define IDC_NEWSERVER                   1058
#define IDC_EDITSERVER                  1059
#define IDC_IRCDCONF                    1059
#define IDC_DELSERVER                   1060
#define IDC_SHOW_GLOBOPS                1060
#define IDC_SHOW_WALLOPS                1061
#define IDC_SHOW_HELPOPS                1062
#define IDC_SHOW_SERVNOTICE             1063
#define IDC_INFOTEXT                    1063
#define IDM_OPEN                        40001
#define IDM_SAVE                        40002
#define IDM_SAVEAS                      40003
#define IDM_EXIT                        40004
#define IDM_ABOUT                       40005
#define IDM_WINDOWCHILD                 40006
#define IDM_REHASH                      40007
#define IDM_OPTIONS                     40008
#define	IDM_CREDITS						40009
#define IDM_DF							40010
#define IDM_LICENSE						40011
#define IDM_DBGOFF                      41099
#define IDM_DBGFATAL                    41100
#define IDM_DBGERROR                    41101
#define IDM_DBGNOTICE                   41103
#define IDM_DBGDNS                      41104
#define IDM_DBGINFO                     41105
#define IDM_DBGNUM                      41106
#define IDM_DBGSEND                     41107
#define IDM_DBGDEBUG                    41108
#define IDM_DBGMALLOC                   41109
#define IDM_DBGLIST                     41110
#define IDM_POPUP                       50000
#define IDC_STATIC                      -1
#define IDM_IRCDRULES					65530
#define IDM_IRCDMOTD					65531
#define IDC_VERSION                     65532
#define IDM_SETUP                       65536
#define IDM_IRCDCONF                    65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1064
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
